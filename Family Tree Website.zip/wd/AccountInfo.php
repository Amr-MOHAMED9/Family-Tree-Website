<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

sec_session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link href="normalize.css" rel="stylesheet" />
    <link href="indexcss.css" rel="stylesheet" />
    <link href="account_info.css" rel="stylesheet" />


</head>

<body>
    <?php include 'includes/bar.php' ?>
    <div class='rightbox'>
        <div class="profile tabShow">
            <?php
            $userID = $_SESSION['user_id'];
            $query = "SELECT * FROM profiles WHERE id='$userID'";

            $result = mysqli_query($mysqli, $query);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_row($result)) {

            ?>


                    <h1>Personal Info</h1>
                    <form action="connect_account.php" method="post">
                        <h3>First Name</h3>
                        <input type="text" class="input" value="<?php echo $row[1]; ?>" name="fname">
                        <h3>Last Name</h3>
                        <input type="text" class="input" value="<?php echo $row[3]; ?>" name="lname">
                        <h3>Common First Name</h3>
                        <input type="text" class="input" value="<?php echo $row[2]; ?>" name="cfname">
                        <h3>Birthday</h3>
                        <input type="date" class="input" value="<?php echo $row[4]; ?>" name="bday">
                        <h3>Nationality</h3>
                        <input type="text" class="input" value="<?php echo $row[5]; ?>" name="nationality">
                        <h3>Email</h3>
                        <input type="text" class="input" value="<?php echo $row[6]; ?>" name="mail">
                        <h3>Phone Number</h3>
                        <input type="text" class="input" value="<?php echo $row[7]; ?>" name="phone">
                        <h3>Gender</h3>
                        <input type="text" class="input" value="<?php echo $row[8]; ?>" name="gender">
                        <h3>Address</h3>
                        <input type="text" class="input" value="<?php echo $row[9]; ?>" name="address">

                        <h3>Occupation</h3>
                        <input type="text" class="input" value="<?php echo $row[10]; ?>" name="ocup">
                        <button class='btn'>Update</button>
                    <?php
                }
            } else { //Close while{} loop
                    ?>
                    <form action="connect_account.php" method="post">
                        <h3>First Name</h3>
                        <input type="text" class="input" name="fname">
                        <h3>Last Name</h3>
                        <input type="text" class="input" name="lname">
                        <h3>Common First Name</h3>
                        <input type="text" class="input" name="cfname">
                        <h3>Birthday</h3>
                        <input type="date" class="input" name="bday">
                        <h3>Nationality</h3>
                        <input type="text" class="input" name="nationality">
                        <h3>Email</h3>
                        <input type="text" class="input" name="mail">
                        <h3>Phone Number</h3>
                        <input type="text" class="input" name="phone">
                        <h3>Gender</h3>
                        <input type="text" class="input" name="gender">
                        <h3>Address</h3>
                        <input type="text" class="input" name="address">
                        <h3>Occupation</h3>
                        <input type="text" class="input" name="ocup">
                        <button class='btn'>Update</button>
                    <?php
                }

                    ?>
                    </form>

        </div>

    </div>
</body>

</html>