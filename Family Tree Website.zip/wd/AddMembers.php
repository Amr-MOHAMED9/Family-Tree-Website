<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

include_once 'includes\db_connect.php';
include_once 'includes/functions.php';

sec_session_start();
// Check connection
if ($mysqli === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
if ($_POST['parent1'] === '') {
    $_POST['parent1'] = NULL; // or 'NULL' for SQL
}
if ($_POST['parent2'] === '') {
    $_POST['parent2'] = NULL; // or 'NULL' for SQL
}
if ($_POST['partner'] === '') {
    $_POST['partner'] = NULL; // or 'NULL' for SQL
}
// Escape user inputs for security
$first_name = mysqli_real_escape_string($mysqli, $_POST['fname']);
$last_name = mysqli_real_escape_string($mysqli, $_POST['lname']);
$cf_name = mysqli_real_escape_string($mysqli, $_POST['cfname']);
$bday = mysqli_real_escape_string($mysqli, $_POST['bday']);
$nation = mysqli_real_escape_string($mysqli, $_POST['nationality']);
$email = mysqli_real_escape_string($mysqli, $_POST['mail']);
$phone = mysqli_real_escape_string($mysqli, $_POST['phone']);
$gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
$address = mysqli_real_escape_string($mysqli, $_POST['address']);
$ocup = mysqli_real_escape_string($mysqli, $_POST['ocup']);
$parent1 = mysqli_real_escape_string($mysqli, $_POST['parent1']);
$parent2 = mysqli_real_escape_string($mysqli, $_POST['parent2']);
$partner = mysqli_real_escape_string($mysqli, $_POST['partner']);
$family = mysqli_real_escape_string($mysqli, $_POST['family']);
$gen = mysqli_real_escape_string($mysqli, $_POST['gen']);
// Attempt insert query execution
$sql = "INSERT INTO people (first_name,common_first_name,last_name,family_ID,parent1_id,parent2_id,partner_id,generation,birth_date,email,nationality,phone_number,gender,occupation,adress) 
VALUES ('$first_name','$cf_name','$last_name','$family','$parent1','$parent2','$partner','$gen','$bday','$nation','$email','$phone','$gender','$ocup','$address')";
if (mysqli_query($mysqli, $sql)) {
    $_SESSION["family"] = $family;
    header('Location: Tree.php');
} else {

    echo "ERROR: Could not able to execute $sql. " . mysqli_error($mysqli);
}

// Close connection
mysqli_close($mysqli);
