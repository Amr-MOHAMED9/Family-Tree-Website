<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

sec_session_start(); 
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <link href="normalize.css" rel="stylesheet" />
        <link href="indexcss.css" rel="stylesheet" />
        <style>
            .mega{
                font-family: "Roboto Slab", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
                color: black; 
                font-weight: bold;
                font-size: 30px
            }
        </style>
    </head>

<body>
    <!-- Navigation-->
    <?php include 'includes/bar.php' ?>
    <?php if (login_check($mysqli) == true) : ?>
                <p style="font-size: 35px;">
                    Welcome back <?php echo(ucfirst(htmlentities($_SESSION['username']))); ?>!
                    <br>
                    <a href="includes/logout.php" class="logout">Sign Out <i class="fas fa-sign-out-alt"></i></a>
                </p>
            <?php else: ?>
                <p>
                    <span class="error"></span> Oh no! It seems that you have not  <a href="LoginPage.php" class="login">logged in <i class="fas fa-sign-in-alt"></i></a> yet. Quick!
                    <br> 
                    <br>
                    <span class="error"></span> Need an account? The magic happens right <a href="RegisterPage.php" class=login>here <i class="fas fa-user-plus"></i></a>!
                </p>
            <?php endif; ?>
</body>

</html>