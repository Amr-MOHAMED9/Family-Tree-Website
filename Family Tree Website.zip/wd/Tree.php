<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

sec_session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link href="normalize.css" rel="stylesheet" />
    <link href="indexcss.css" rel="stylesheet" />
    <link href="account_info.css" rel="stylesheet" />

</head>

<body>
    <!-- Navigation-->
    <?php include 'includes/bar.php' ?>
    <div id="mynetwork" style="height: 700px; width: 100%;"></div>
    <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>

    <?php if (login_check($mysqli) == true) :
        $nodes = array();
        $edges = array();
        if (isset($_POST['family'])) {
            $family = mysqli_real_escape_string($mysqli, $_POST['family']);
        } else {
            $family = null;
        }

        if ($family == null) {
            $userid = $_SESSION['user_id'];
            $sqlFm = mysqli_query($mysqli, "SELECT * FROM profiles WHERE id = '$userid'");
            while ($row = $sqlFm->fetch_assoc()) {
                $family = $row['family_id'];
            }
        }
        $sql = mysqli_query($mysqli, "SELECT * FROM people WHERE family_ID = '$family'");
        while ($row = $sql->fetch_assoc()) {
            $node = array(
                "id" => $row["id"],
                //"shape" => "image",
                //"image" => "",
                //"brokenImage" => "Images/user.png",
                "label" => $row["first_name"] . " " . $row["last_name"] . " - Gen:" . $row["generation"],
                "level" => $row["generation"],
                "group" => $row["generation"]
            );
            $edge1 = array("from" => $row["id"], "to" => $row["parent1_id"]);
            $edge2 = array("from" => $row["id"], "to" => $row["parent2_id"]);
            $edge3 = array("from" => $row["id"], "to" => $row["partner_id"], "color" => 'rgb(255,0,0)');
            array_push($edges, $edge1, $edge2, $edge3);
            array_push($nodes, $node);
        }

    ?>
        <p style="font-size: 35px;">
            <script type="text/javascript">
                // create an array with nodes
                var nodes = <?php echo json_encode($nodes); ?>;
                /* {
                     id: 5,
                     shape: "image",
                     image: "",
                     brokenImage: "Images/user.png",
                     label: "Name, Family Name1, Family Name2",
                     level: 0,
                 }*/



                // create an array with edges
                var edges = <?php echo json_encode($edges); ?>;

                // create a network
                var container = document.getElementById("mynetwork");
                var data = {
                    nodes: nodes,
                    edges: edges
                };
                var options = {
                    layout: {
                        hierarchical: {
                            direction: "UD",
                        }
                    },
                    physics: {
                        hierarchicalRepulsion: {
                            avoidOverlap: 0.7,
                        }
                    },
                };
                var network = new vis.Network(container, data, options);
            </script>
        </p>
        <div class='rightbox'>
            <div class="profile tabShow">
                <form action="AddMembers.php" method="post">
                    <h2>Add Family Member</h2>
                    <h3>First Name</h3>
                    <input type="text" class="input" name="fname">
                    <h3>Last Name</h3>
                    <input type="text" class="input" name="lname">
                    <h3>Common First Name</h3>
                    <input type="text" class="input" name="cfname">
                    <h3>Parent 1</h3>
                    <select name="parent1">
                        <option value=<?php echo null ?>>None</option>
                        <?php
                        $userid = $_SESSION['user_id'];
                        $family = mysqli_real_escape_string($mysqli, $_POST['family']);
                        $sql = mysqli_query($mysqli, "SELECT * FROM people WHERE family_ID = '$family'");
                        while ($row = $sql->fetch_assoc()) {
                            echo "<option value=" . $row['id'] . ">" . $row['first_name'] . " " . $row['last_name'] . "</option>";
                        }
                        ?>
                    </select>
                    <h3>Parent 2 </h3>
                    <select name="parent2">
                        <option value=<?php echo null ?>>None</option>
                        <?php
                        $userid = $_SESSION['user_id'];
                        $family = mysqli_real_escape_string($mysqli, $_POST['family']);
                        $sql = mysqli_query($mysqli, "SELECT * FROM people WHERE family_ID = '$family'");
                        while ($row = $sql->fetch_assoc()) {
                            echo "<option value=" . $row['id'] . ">" . $row['first_name'] . " " . $row['last_name'] . "</option>";
                        }
                        ?>
                    </select>
                    <h3>Partner </h3>
                    <select name="partner">
                        <option value=<?php echo null ?>>None</option>
                        <?php
                        $userid = $_SESSION['user_id'];
                        $family = mysqli_real_escape_string($mysqli, $_POST['family']);
                        $sql = mysqli_query($mysqli, "SELECT * FROM people WHERE family_ID = '$family'");
                        while ($row = $sql->fetch_assoc()) {
                            echo "<option value=" . $row['id'] . ">" . $row['first_name'] . " " . $row['last_name'] . "</option>";
                        }
                        ?>
                    </select>
                    <h3>Generation</h3>
                    <input type="number" class="input" name="gen">
                    <h3>Birthday</h3>
                    <input type="date" class="input" name="bday">
                    <h3>Nationality</h3>
                    <input type="text" class="input" name="nationality">
                    <h3>Email</h3>
                    <input type="text" class="input" name="mail">
                    <h3>Phone Number</h3>
                    <input type="text" class="input" name="phone">
                    <h3>Gender</h3>
                    <input type="text" class="input" name="gender">
                    <h3>Address</h3>
                    <input type="text" class="input" name="address">
                    <h3>Occupation</h3>
                    <input type="text" class="input" name="ocup">
                    <br>
                    <input type="hidden" name="family" value=<?php echo $family ?>>
                    <button class='btn'>Add</button>
                </form>
            </div>
        </div>
    <?php else :
    ?>
        <p>
            <span class="error"></span> Oh no! It seems that you have not <a href="LoginPage.php" class="login">logged in <i class="fas fa-sign-in-alt"></i></a> yet. Quick!
            <br>
            <br>
            <span class="error"></span> Need an account? The magic happens right <a href="RegisterPage.php" class=login>here <i class="fas fa-user-plus"></i></a>!
        </p>
    <?php endif; ?>
</body>

</html>