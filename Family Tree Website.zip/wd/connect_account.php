<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

include_once 'includes\db_connect.php';
include_once 'includes/functions.php';

sec_session_start();
// Check connection
if ($mysqli === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Escape user inputs for security
$first_name = mysqli_real_escape_string($mysqli, $_POST['fname']);
$last_name = mysqli_real_escape_string($mysqli, $_POST['lname']);
$cf_name = mysqli_real_escape_string($mysqli, $_POST['cfname']);
$bday = mysqli_real_escape_string($mysqli, $_POST['bday']);
$nation = mysqli_real_escape_string($mysqli, $_POST['nationality']);
$email = mysqli_real_escape_string($mysqli, $_POST['mail']);
$phone = mysqli_real_escape_string($mysqli, $_POST['phone']);
$gender = mysqli_real_escape_string($mysqli, $_POST['gender']);
$address = mysqli_real_escape_string($mysqli, $_POST['address']);
$ocup = mysqli_real_escape_string($mysqli, $_POST['ocup']);
$userid = mysqli_real_escape_string($mysqli, $_SESSION['user_id']);

// Attempt insert query execution
$sql = "INSERT INTO profiles (id,first_name,common_first_name,last_name,birthday,nationality,email,phone_number,gender,adress,occupation) 
VALUES ('$userid','$first_name','$cf_name','$last_name','$bday','$nation','$email','$phone','$gender','$address','$ocup')
ON DUPLICATE KEY UPDATE first_name='$first_name',common_first_name='$cf_name',last_name='$last_name',birthday='$bday',email='$email',nationality='$nation',phone_number='$phone',gender='$gender',adress='$address', occupation='$ocup'";
if (mysqli_query($mysqli, $sql)) {

    header('Location: AccountInfo.php');
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($mysqli);
