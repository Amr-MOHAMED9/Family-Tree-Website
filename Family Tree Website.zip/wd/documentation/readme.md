To launch the website:
1)You need to run xampp
2)Put the wd file in the httdocs folder
3)Run the web services and the database
4)Run the SQL Project1 file to create the db
5)And access the local host on the browser
