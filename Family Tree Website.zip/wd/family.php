<?php
include_once 'includes/db_connect.php';
include_once 'includes/functions.php';

sec_session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link href="normalize.css" rel="stylesheet" />
    <link href="indexcss.css" rel="stylesheet" />

    <style>
        .rightbox {
            width: 60%;
            margin-left: 27%;
        }

        .tabshow {
            transition: all .5s ease-in;
            width: 80%;
        }

        h1 {
            font-family: "Roboto Slab", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            color: black;
            font-size: 22px;
        }

        h3 {
            font-family: "Roboto Slab", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            color: black;
            font-size: 15px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-left: 2px;

        }

        input {
            border: 0;
            border-bottom: 1px solid #3fb6a8;
            width: 70%;
            font-family: "Roboto Slab", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            border-radius: 25px;
            border: 5px solid black;
            padding: 20px;
            width: 650px;
            font-size: 14px;
            font-weight: bold;
            height: 2px;
        }

        select {
            border: 0;
            border-bottom: 1px solid #3fb6a8;
            width: 70%;
            font-family: "Roboto Slab", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            border-radius: 25px;
            border: 5px solid black;
            padding: 20px;
            width: 695px;
            font-size: 14px;
            font-weight: bold;

        }

        .btn {
            font-family: "Roboto Slab", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
            text-transform: uppercase;
            border: 0;
            background: black;
            padding: 7px 15px;
            box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 2);
            cursor: pointer;
            margin-top: 15px;
            margin-left: 32%;
            border-radius: 25px;
            width: 209x;
            font-size: 18px;
            font-weight: bold;
            color: white;
            border: 8px white;
        }
    </style>


</head>

<body>
    <?php include 'includes\bar.php' ?>
    <div class='rightbox'>
        <div class="profile tabShow">

            <?php $checkfamily = mysqli_query($mysqli, "SELECT family_id FROM profiles WHERE id = '$_SESSION[user_id]' AND family_id IS NOT null");

            if (mysqli_num_rows($checkfamily) > 0) {
            ?><form action="Tree.php" method="post">
                    <select name="family">
                        <?php
                        $sql = mysqli_query($mysqli, "SELECT * FROM family");
                        while ($row = $sql->fetch_assoc()) {
                            echo "<option value=" . $row['id'] . ">" . $row['familyName'] . "</option>";
                        }
                        ?>

                    </select>
                    <button class='btn'>Search</button>
                </form>
            <?php
            } else { ?>
                <form action="setfamily.php" method="post">
                    <h2>Join a family</h2>
                    <select name="family">
                        <?php
                        $sql = mysqli_query($mysqli, "SELECT * FROM family");
                        while ($row = $sql->fetch_assoc()) {
                            echo "<option value=" . $row['id'] . ">" . $row['familyName'] . "</option>";
                        }
                        ?>
                    </select> <br>
                    <button class='btn'>Join</button>
                </form>
                <form action="createfamily.php" method="post">
                    <h2>Create a family:</h2>
                    <h3>Family Name</h3>
                    <input type="text" class="input" name="famname">
                    <h3>Image</h3>
                    <input type="text" class="input" name="img">
                    <button class='btn'>Create</button>
                </form>


            <?php }
            ?>

        </div>

    </div>
</body>

</html>