<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link href="normalize.css" rel="stylesheet" />
    <link href="indexcss.css" rel="stylesheet" />
</head>

<body>
    <!-- Navigation-->
    <div class='navbar'>
        <div class='container'>
            <div class='brand'>
                <h2>GAG</h2>
            </div>
            <ul class="links">
                <?php if (basename($_SERVER['PHP_SELF']) == 'Index.php') { ?>
                    <a class="active">Home</a>
                    <a href="Tree.php">Your family tree</a>
                    <a href="messenger.php">Messages</a>
                    <a href="family.php">Search</a>
                    <a href="AccountInfo.php">Account info</a>
                <?php } elseif (basename($_SERVER['PHP_SELF']) == 'Tree.php') { ?>
                    <a href="Index.php">Home</a>
                    <a class="active">Your family tree</a>
                    <a href="messenger.php">Messages</a>
                    <a href="family.php">Search</a>
                    <a href="AccountInfo.php">Account info</a>
                <?php } elseif (basename($_SERVER['PHP_SELF']) == 'messenger.php') { ?>
                    <a href="Index.php">Home</a>
                    <a href="Tree.php">Your family tree</a>
                    <a class="active">Messages</a>
                    <a href="family.php">Search</a>
                    <a href="AccountInfo.php">Account info</a>
                <?php } elseif (basename($_SERVER['PHP_SELF']) == 'family.php') { ?>
                    <a href="Index.php">Home</a>
                    <a href="Tree.php">Your family tree</a>
                    <a href="messenger.php">Messages</a>
                    <a class="active">Search</a>
                    <a href="AccountInfo.php">Account info</a>
                <?php } elseif (basename($_SERVER['PHP_SELF']) == 'AccountInfo.php') { ?>
                    <a href="Index.php">Home</a>
                    <a href="Tree.php">Your family tree</a>
                    <a href="messenger.php">Messages</a>
                    <a href="family.php">Search</a>
                    <a class="active">Account info</a>
                <?php } ?>
            </ul>
            <div class='clearfix'></div>
        </div>
    </div>
    <script src="jquery-3.5.1.min.js"></script>
    <script src="customjs.js"></script>
</body>

</html>