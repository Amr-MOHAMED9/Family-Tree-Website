<?php


  
define("HOST", "localhost");     
define("USER", "root");    
define("PASSWORD", "");   
define("DATABASE", "project1");  
//define("CAN_REGISTER", "any");*/
//define("DEFAULT_ROLE", "member");

define("SECURE", FALSE);
?>