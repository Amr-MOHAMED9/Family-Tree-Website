-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22-Jan-2021 às 16:17
-- Versão do servidor: 10.4.8-MariaDB
-- versão do PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `project1`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `family`
--

CREATE TABLE `family` (
  `id` int(11) NOT NULL,
  `familyName` text NOT NULL,
  `imgPath` text NOT NULL,
  `familyCreator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `family`
--

INSERT INTO `family` (`id`, `familyName`, `imgPath`, `familyCreator`) VALUES
(1, 'Borges', '', 7),
(2, 'Albino', '', 7);

-- --------------------------------------------------------

--
-- Estrutura da tabela `people`
--

CREATE TABLE `people` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `common_first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `family_ID` int(11) DEFAULT NULL,
  `parent1_id` int(11) DEFAULT NULL,
  `parent2_id` int(11) DEFAULT NULL,
  `partner_id` int(11) DEFAULT NULL,
  `generation` int(11) NOT NULL,
  `birth_date` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `gender` char(1) DEFAULT NULL,
  `occupation` varchar(50) NOT NULL,
  `adress` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `people`
--

INSERT INTO `people` (`id`, `first_name`, `common_first_name`, `last_name`, `family_ID`, `parent1_id`, `parent2_id`, `partner_id`, `generation`, `birth_date`, `email`, `nationality`, `phone_number`, `gender`, `occupation`, `adress`) VALUES
(1, 'Harry', 'Potter', 'Potter', 1, NULL, NULL, NULL, 0, '1980-07-31', 'harry_potter@hogwarts.en', '', '(605) 475-6961', 'M', 'Wizard', 'The cupboard under the stairs, 4 Privet Drive, Little Whinging, SURREY'),
(2, 'Harry', 'Potter', 'Potter the second', 1, 1, 4, NULL, 1, '1980-07-31', 'harry_potter@hogwarts.en', '', '(605) 475-6961', 'M', 'Wizard', 'The cupboard under the stairs, 4 Privet Drive, Little Whinging, SURREY'),
(3, 'Harry', 'Potter', 'Potter the second brother', 1, 1, 4, NULL, 1, '1980-07-31', 'harry_potter@hogwarts.en', '', '(605) 475-6961', 'M', 'Wizard', 'The cupboard under the stairs, 4 Privet Drive, Little Whinging, SURREY'),
(4, 'Harry', 'Potter', 'Potter Wife', 1, NULL, NULL, 1, 0, '1980-07-31', 'harry_potter@hogwarts.en', '', '(605) 475-6961', 'M', 'Wizard', 'The cupboard under the stairs, 4 Privet Drive, Little Whinging, SURREY'),
(6, 'Harry', 'Potter', 'Potter  Grampa', 1, NULL, NULL, NULL, -1, '1980-07-31', 'harry_potter@hogwarts.en', '', '(605) 475-6961', 'M', 'Wizard', 'The cupboard under the stairs, 4 Privet Drive, Little Whinging, SURREY'),
(15, 'Gabriel', 'Gabriel', 'Albino', 2, 0, 0, 0, 0, '1993-10-30', 'Brazil', 'gabriel_albino_5@hotmail.com', '0752719173', 'M', 'Student', 'Putterplantsoen');

-- --------------------------------------------------------

--
-- Estrutura da tabela `profiles`
--

CREATE TABLE `profiles` (
  `id` int(11) UNSIGNED NOT NULL,
  `first_name` varchar(15) NOT NULL,
  `common_first_name` varchar(15) DEFAULT NULL,
  `last_name` varchar(15) NOT NULL,
  `birthday` date NOT NULL,
  `nationality` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `gender` tinytext DEFAULT NULL,
  `adress` varchar(200) DEFAULT NULL,
  `occupation` varchar(30) DEFAULT NULL,
  `family_id` int(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `profiles`
--

INSERT INTO `profiles` (`id`, `first_name`, `common_first_name`, `last_name`, `birthday`, `nationality`, `email`, `phone_number`, `gender`, `adress`, `occupation`, `family_id`) VALUES
(7, 'Gabriel', 'Gabriel', 'Albino', '1993-10-30', 'Brazil', 'gabriel_albino_5@hotmail.com', '999999999', 'Male', 'Test address', 'Student', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

CREATE TABLE `user` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` mediumtext NOT NULL,
  `password` mediumtext NOT NULL,
  `email` text NOT NULL,
  `salt` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `salt`) VALUES
(4, 'shakadaran', 'e6a4c45b7d8f33bc1f3c7de45ac3cd4c2a0da98f610e3f00f541dcd560dbb61c762e9f7ff01d122b753152b34eb23204c3f760ebb8baeebcc5ef9ebf916d299f', 'gabriel@test.com', 'ee91aa3b981184bc16fdd79d9872e14e591936619a87c31bb2502fbc71a612657af9fda2889ebd8b630074fdf06c006cbf92eeaf72459768c02f037129492898'),
(5, 'gabriel', '143581340b733470917112754ae8566a004b4106cc7f3b570a3360ba1708b072ad6eddf9259aa997992c1c3d8a3f9e40a98145a9d1564674c9a47388f4a4e747', 'test@test.com', '54c1e51b86872272dc4323946cea8a11a2b5ea014daef953a432585ac5a20f03e63e7c397a55bb311babd643ccea52040e4d9b0bad767d43cbaf1f603e0c8987'),
(6, 'gabrielba', '5938bdc23485904ad41b12c59a3fc05007ae21b3d6075c398a1596bfba194fe33d2f3f389a0b7c81be4cf5be461877881e5dd2297efe509a8222133517cb7358', 'test@test1.com', '44d8664a8123be51d6e59c8ff78730c0c035fad2acd1a03c6fea6fd8d0e689c6c11d9d031ecbeb068901f0a0439b4e96e5b4abc066121eaf0d23b37056958459'),
(7, 'albgabr', '980dcaf49b42dfb1627d3e55dbb68f34996ce1a0755c9a182937dc3fb81d8865ba8e0c2bd5a79da8ca3d175804a5df0566fc29bec82a7e499fe07db9cee391f5', 'albgabr@eisti.eu', 'e61fcdafeba2ded5c1f028255b3ba95fd41008b4c4c9377224ef8935ed71d3c3735d2421f54909f5fb4317069aafc1fc40ca8dbcd4e020347c2090e08d9253cf');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `family`
--
ALTER TABLE `family`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FamName` (`family_ID`),
  ADD KEY `parent1` (`parent1_id`),
  ADD KEY `parent2` (`parent2_id`),
  ADD KEY `partner` (`partner_id`);

--
-- Índices para tabela `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `family`
--
ALTER TABLE `family`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `people`
--
ALTER TABLE `people`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `id_user_prof` FOREIGN KEY (`id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
