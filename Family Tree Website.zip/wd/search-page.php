<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <link href="normalize.css" rel="stylesheet" />
        <link href="indexcss.css" rel="stylesheet" />
    </head>

    <body >
        <!-- Navigation-->
        <?php include 'includes/bar.php' ?>
    </body>
</html>