<?php
include_once 'includes\db_connect.php';
include_once 'includes/functions.php';

sec_session_start();
// Check connection
if ($mysqli === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Escape user inputs for security
$familyID = mysqli_real_escape_string($mysqli, $_POST['family']);
$userid = mysqli_real_escape_string($mysqli, $_SESSION['user_id']);

// Attempt insert query execution
$sql = "UPDATE profiles SET family_id='$familyID' WHERE id='$userid'";
if (mysqli_query($mysqli, $sql)) {

    header('Location: family.php');
} else {
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($mysqli);
}

// Close connection
mysqli_close($mysqli);
